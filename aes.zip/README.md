# crypto-aes-js-php

lambert
本包是js和php 交互aes加密实例：
 	js加密 解密
 	php解密 加密   index.html已经写好
