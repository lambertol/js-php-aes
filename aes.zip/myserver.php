<?php

  include 'LegierskiAES/aes.php';

  $cryption = (string)$_POST['cryption'];
  $aes = new \Legierski\AES\AES();
  $hash = 'e8a3295ca4fe5b1e3675816317f665e0';
  //解密
  $decrypted = $aes->decrypt($cryption, $hash);
  $json = json_encode(array("user"=>"我擦1"));
  //加密
  $jismi = $aes->encrypt($json,$hash);
  echo '后端的解密'.$decrypted;
  // var_dump("json:".$json);
  // echo "<hr/>";
  echo '后端的加密--'.$jismi;

?>
